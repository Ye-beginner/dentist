
export enum GameStatus {
  IDLE = 'IDLE',
  DRILLING = 'DRILLING',
  PREPPED = 'PREPPED', // Stage 1 complete (Shining Prep)
  FILLING = 'FILLING', // Stage 2 active
  SUCCESS = 'SUCCESS', // Finished (White Tooth)
  PULP_EXPOSURE = 'PULP_EXPOSURE'
}

export enum Tool {
  AERATOR = 'AERATOR',
  SPATULA = 'SPATULA'
}

export interface ToolCalibration {
  scale: number;
  rotation: number;
  pivotX: number;
  pivotY: number;
}

export interface CavityConfig {
  id: string;
  x: number;
  y: number;
  radius: number;
  progress: number;      // Prep progress 0-110
  fillProgress: number;  // Filling progress 0-100
  status: GameStatus;
}
