
import React, { useRef, useState, useEffect, useCallback } from 'react';
import { GameStatus, CavityConfig, Tool, ToolCalibration } from '../types';

interface MouthViewProps {
  cavities: CavityConfig[];
  activeId: string | null;
  onMouseDown: (id: string) => void;
  onMouseUp: () => void;
  onScrub: (id: string, distance: number) => void;
  onProgressUpdate: (id: string, progress: number) => void;
  isDesignerMode: boolean;
  onUpdateCavity: (id: string, updates: Partial<CavityConfig>) => void;
  currentTool: Tool;
  calibration: ToolCalibration;
  spatulaCalibration: ToolCalibration;
}

const CAVITY_SHAPE_URL = "https://res.cloudinary.com/dqwydvc0p/image/upload/v1769514169/Screenshot_20260127_142920_Gallery_1_ywdoam.png";
const AERATOR_IMAGE_URL = "https://res.cloudinary.com/dqwydvc0p/image/upload/v1769516190/IMG-20260127-WA0004_kbmjuz.png";
const SPATULA_IMAGE_URL = "https://res.cloudinary.com/dqwydvc0p/image/upload/v1769625411/IMG-20260128-WA0072_wvjhhv.png";

const MouthView: React.FC<MouthViewProps> = ({ 
  cavities,
  activeId,
  onMouseDown, 
  onMouseUp, 
  onScrub,
  onProgressUpdate,
  isDesignerMode, 
  onUpdateCavity,
  currentTool,
  calibration,
  spatulaCalibration
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [mousePos, setMousePos] = useState({ x: 0, y: 0 });
  const dragRef = useRef<{ id: string } | null>(null);
  const [isCanvasReady, setIsCanvasReady] = useState(false);
  const initialPixelCounts = useRef<Record<string, number>>({});

  // Initialize Canvas and draw decay without distortion
  // In Designer Mode, we redraw on every change to keep the canvas in sync
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas || !containerRef.current) return;

    const ctx = canvas.getContext('2d', { willReadFrequently: true });
    if (!ctx) return;

    const rect = containerRef.current.getBoundingClientRect();
    canvas.width = rect.width;
    canvas.height = rect.height;

    const decayImg = new Image();
    decayImg.crossOrigin = "anonymous";
    decayImg.src = CAVITY_SHAPE_URL;
    
    decayImg.onload = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      
      cavities.forEach(c => {
        // Drawing on canvas only for the prep stage
        if (c.status === GameStatus.IDLE || c.status === GameStatus.DRILLING) {
          const x = (c.x / 100) * canvas.width;
          const y = (c.y / 100) * canvas.height;
          const size = (c.radius * 2.5 / 100) * canvas.width;
          
          ctx.save();
          ctx.globalCompositeOperation = 'source-over';
          ctx.filter = 'brightness(0.4) sepia(0.2) contrast(1.1)';
          ctx.drawImage(decayImg, x - size/2, y - size/2, size, size);
          
          // Accurately count initial pixels for progress tracking
          const region = ctx.getImageData(x - size/2, y - size/2, size, size).data;
          let opaque = 0;
          for(let i=3; i < region.length; i += 4) {
            if(region[i] > 20) opaque++;
          }
          initialPixelCounts.current[c.id] = opaque;
          ctx.restore();
        }
      });
      setIsCanvasReady(true);
    };
  }, [isDesignerMode, cavities.length, isDesignerMode ? cavities : null]); 

  const checkProgress = useCallback((id: string) => {
    const canvas = canvasRef.current;
    const ctx = canvas?.getContext('2d');
    const c = cavities.find(cav => cav.id === id);
    if (!canvas || !ctx || !c || initialPixelCounts.current[id] === undefined) return;

    const x = (c.x / 100) * canvas.width;
    const y = (c.y / 100) * canvas.height;
    const size = (c.radius * 2.5 / 100) * canvas.width;
    
    const imageData = ctx.getImageData(x - size/2, y - size/2, size, size);
    const data = imageData.data;
    let opaquePixels = 0;
    
    for (let i = 3; i < data.length; i += 4) {
      if (data[i] > 20) opaquePixels++;
    }

    const initial = initialPixelCounts.current[id];
    const cleared = initial - opaquePixels;
    const progressPercent = Math.min(100, (cleared / initial) * 100);
    
    onProgressUpdate(id, progressPercent);
  }, [cavities, onProgressUpdate]);

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!containerRef.current) return;
    const rect = containerRef.current.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    setMousePos({ x, y });

    if (activeId && !isDesignerMode) {
      if (currentTool === Tool.AERATOR && canvasRef.current) {
        const ctx = canvasRef.current.getContext('2d');
        if (ctx) {
          ctx.save();
          ctx.globalCompositeOperation = 'destination-out';
          ctx.beginPath();
          ctx.arc(x, y, 12 * calibration.scale, 0, Math.PI * 2);
          ctx.fill();
          ctx.restore();
          
          if (Math.random() > 0.85) checkProgress(activeId);
        }
      } else if (currentTool === Tool.SPATULA) {
        const dx = e.movementX;
        const dy = e.movementY;
        const dist = Math.sqrt(dx * dx + dy * dy);
        if (dist > 1.5) onScrub(activeId, dist);
      }
    }

    if (isDesignerMode && dragRef.current) {
      const pxX = (x / rect.width) * 100;
      const pxY = (y / rect.height) * 100;
      onUpdateCavity(dragRef.current.id, { x: pxX, y: pxY });
    }
  };

  const handleWheel = (e: React.WheelEvent) => {
    if (!isDesignerMode || !activeId) return;
    const cavity = cavities.find(c => c.id === activeId);
    if (!cavity) return;

    // Scroll to scale the cavity area
    const delta = e.deltaY > 0 ? -0.2 : 0.2;
    onUpdateCavity(activeId, {
      radius: Math.max(1, Math.min(40, cavity.radius + delta))
    });
  };

  const handleGlobalMouseUp = () => {
    if (activeId) checkProgress(activeId);
    dragRef.current = null;
    onMouseUp();
  };

  const shouldVibrate = activeId && !isDesignerMode && currentTool === Tool.AERATOR;

  return (
    <div 
      ref={containerRef}
      className={`relative w-full h-full overflow-hidden select-none cursor-none ${shouldVibrate ? 'vibrate' : ''}`}
      onMouseMove={handleMouseMove}
      onMouseUp={handleGlobalMouseUp}
      onMouseLeave={handleGlobalMouseUp}
      onWheel={handleWheel}
    >
      <img 
        src="https://res.cloudinary.com/dqwydvc0p/image/upload/v1769510429/Gemini_Generated_Image_4dj7lo4dj7lo4dj7_aqgrn2.png" 
        alt="Tooth Base"
        className="w-full h-full object-contain pointer-events-none brightness-95 contrast-110"
        draggable={false}
      />

      <canvas 
        ref={canvasRef}
        className="absolute inset-0 w-full h-full pointer-events-none"
        style={{ 
          opacity: isDesignerMode ? 0.3 : 1,
          visibility: cavities.some(c => c.status === GameStatus.SUCCESS || c.status === GameStatus.PREPPED) ? 'hidden' : 'visible'
        }}
      />

      <div className="absolute inset-0 pointer-events-none">
        {cavities.map((c) => {
          const isPulpExposed = c.status === GameStatus.PULP_EXPOSURE;
          const isPrepped = c.status === GameStatus.PREPPED || c.status === GameStatus.FILLING || c.status === GameStatus.SUCCESS;
          const isFullyFinished = c.status === GameStatus.SUCCESS;
          const isActive = activeId === c.id;

          const shiningOpacity = (c.status === GameStatus.PREPPED || c.status === GameStatus.FILLING) ? Math.max(0, 1 - c.fillProgress / 100) : 0;

          return (
            <div 
              key={c.id} 
              className="absolute pointer-events-auto"
              style={{
                left: `${c.x}%`,
                top: `${c.y}%`,
                width: `${c.radius * 2.5}%`,
                height: `${c.radius * 2.5}%`,
                transform: 'translate(-50%, -50%)',
                cursor: 'none'
              }}
              onMouseDown={(e) => {
                e.stopPropagation();
                if (isDesignerMode) dragRef.current = { id: c.id };
                onMouseDown(c.id);
              }}
            >
              <div 
                className="absolute inset-0 pointer-events-none transition-opacity duration-300" 
                style={{ opacity: shiningOpacity }}
              >
                <img 
                  src={CAVITY_SHAPE_URL}
                  alt="Bonding"
                  className="absolute inset-0 w-full h-full object-contain"
                  style={{ 
                    filter: 'brightness(3) drop-shadow(0 0 10px rgba(255,255,255,0.8)) grayscale(0.5)',
                  }}
                />
                <div className="absolute inset-0 overflow-hidden rounded-full" 
                     style={{ 
                         maskImage: `url(${CAVITY_SHAPE_URL})`, maskSize: 'contain', 
                         WebkitMaskImage: `url(${CAVITY_SHAPE_URL})`, WebkitMaskSize: 'contain', 
                         WebkitMaskRepeat: 'no-repeat', WebkitMaskPosition: 'center' 
                     }}>
                  <div className="shimmer" />
                </div>
              </div>

              {isPulpExposed && (
                <div className="absolute inset-0 flex items-center justify-center">
                   <div className="w-[70%] h-[70%] bg-red-600/80 rounded-full blur-xl animate-pulse shadow-[0_0_40px_#f00]" />
                </div>
              )}

              {isFullyFinished && (
                 <div className="absolute inset-0 flex items-center justify-center text-3xl drop-shadow-xl animate-bounce pointer-events-none">✨</div>
              )}
              
              {isDesignerMode && (
                <div className={`absolute inset-0 rounded-full border-2 ${isActive ? 'border-emerald-500 bg-emerald-500/20' : 'border-white/30'}`} />
              )}
            </div>
          );
        })}
      </div>

      <div 
        className="absolute pointer-events-none z-[500]"
        style={{ 
          left: mousePos.x, 
          top: mousePos.y,
        }}
      >
        {currentTool === Tool.AERATOR ? (
           <div 
             style={{
               transform: `translate(${calibration.pivotX}px, ${calibration.pivotY}px) rotate(${calibration.rotation}deg) scale(${calibration.scale})`, 
               transformOrigin: '0% 0%',
               transition: 'none'
             }}
           >
               <img src={AERATOR_IMAGE_URL} className="w-80 drop-shadow-[0_20px_40px_rgba(0,0,0,0.7)]" alt="Aerator" />
               {activeId && !isDesignerMode && (
                 <div className="absolute top-0 left-0 w-24 h-24 -translate-x-1/2 -translate-y-1/2">
                   <div className="absolute inset-0 text-white text-4xl animate-ping">✧</div>
                 </div>
               )}
           </div>
        ) : (
           <div 
             style={{
               transform: `translate(${spatulaCalibration.pivotX}px, ${spatulaCalibration.pivotY}px) rotate(${spatulaCalibration.rotation}deg) scale(${spatulaCalibration.scale})`,
               transformOrigin: '100% 50%',
               transition: 'none'
             }}
           >
               <img src={SPATULA_IMAGE_URL} className="w-80 drop-shadow-[0_20px_40px_rgba(0,0,0,0.7)]" alt="Spatula" />
           </div>
        )}
      </div>

      {isDesignerMode && (
        <div className="absolute bottom-10 left-1/2 -translate-x-1/2 bg-emerald-600 text-white px-12 py-4 rounded-full font-black text-xs uppercase tracking-[0.5em] shadow-[0_20px_50px_rgba(5,150,105,0.5)] z-[1000] border-2 border-white/20">
          Cavity Alignment Mode • Drag to move • Scroll to resize
        </div>
      )}
    </div>
  );
};

export default MouthView;
