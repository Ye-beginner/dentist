
class AudioService {
  private audioCtx: AudioContext | null = null;
  private oscillator: OscillatorNode | null = null;
  private gainNode: GainNode | null = null;

  private init() {
    if (!this.audioCtx) {
      this.audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)();
    }
  }

  public startBuzz() {
    this.init();
    if (!this.audioCtx) return;
    if (this.audioCtx.state === 'suspended') this.audioCtx.resume();
    this.stopBuzz();

    this.oscillator = this.audioCtx.createOscillator();
    this.gainNode = this.audioCtx.createGain();
    this.oscillator.type = 'sawtooth';
    this.oscillator.frequency.setValueAtTime(440, this.audioCtx.currentTime);
    this.oscillator.frequency.exponentialRampToValueAtTime(880, this.audioCtx.currentTime + 0.1);
    
    const mod = this.audioCtx.createOscillator();
    const modGain = this.audioCtx.createGain();
    mod.frequency.value = 50;
    modGain.gain.value = 20;
    mod.connect(modGain);
    modGain.connect(this.oscillator.frequency);
    mod.start();

    this.gainNode.gain.setValueAtTime(0, this.audioCtx.currentTime);
    this.gainNode.gain.linearRampToValueAtTime(0.08, this.audioCtx.currentTime + 0.05);

    this.oscillator.connect(this.gainNode);
    this.gainNode.connect(this.audioCtx.destination);
    this.oscillator.start();
  }

  public playSpatula() {
    this.init();
    if (!this.audioCtx) return;
    
    const osc = this.audioCtx.createOscillator();
    const g = this.audioCtx.createGain();
    osc.connect(g);
    g.connect(this.audioCtx.destination);
    
    osc.type = 'sine';
    osc.frequency.setValueAtTime(120, this.audioCtx.currentTime);
    osc.frequency.exponentialRampToValueAtTime(40, this.audioCtx.currentTime + 0.1);
    
    g.gain.setValueAtTime(0.1, this.audioCtx.currentTime);
    g.gain.linearRampToValueAtTime(0, this.audioCtx.currentTime + 0.1);
    
    osc.start();
    osc.stop(this.audioCtx.currentTime + 0.1);
  }

  public stopBuzz() {
    if (this.oscillator) {
      try { this.oscillator.stop(); this.oscillator.disconnect(); } catch (e) {}
      this.oscillator = null;
    }
    if (this.gainNode) {
      this.gainNode.disconnect();
      this.gainNode = null;
    }
  }

  public playSuccess() {
    this.init();
    if (!this.audioCtx) return;
    const osc = this.audioCtx.createOscillator();
    const g = this.audioCtx.createGain();
    osc.connect(g);
    g.connect(this.audioCtx.destination);
    osc.frequency.setValueAtTime(523.25, this.audioCtx.currentTime);
    osc.frequency.exponentialRampToValueAtTime(1046.50, this.audioCtx.currentTime + 0.5);
    g.gain.setValueAtTime(0.1, this.audioCtx.currentTime);
    g.gain.exponentialRampToValueAtTime(0.01, this.audioCtx.currentTime + 0.5);
    osc.start();
    osc.stop(this.audioCtx.currentTime + 0.5);
  }

  public playSuccessSpeech() {
    const audio = new Audio("https://res.cloudinary.com/dqwydvc0p/video/upload/v1769642689/ElevenLabs_2026-01-28T23_23_31_Hope_-_upbeat_and_clear_pvc_sp96_s50_sb75_se0_b_m2_gj31ra.mp3");
    audio.play().catch(e => console.error("Audio playback failed", e));
  }

  public playFail() {
    this.init();
    if (!this.audioCtx) return;
    const osc = this.audioCtx.createOscillator();
    const g = this.audioCtx.createGain();
    osc.connect(g);
    g.connect(this.audioCtx.destination);
    osc.frequency.setValueAtTime(150, this.audioCtx.currentTime);
    osc.frequency.linearRampToValueAtTime(50, this.audioCtx.currentTime + 0.3);
    g.gain.setValueAtTime(0.2, this.audioCtx.currentTime);
    g.gain.linearRampToValueAtTime(0, this.audioCtx.currentTime + 0.3);
    osc.start();
    osc.stop(this.audioCtx.currentTime + 0.3);
  }
}

export const audioService = new AudioService();
