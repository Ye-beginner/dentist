
import React, { useState, useEffect, useCallback, useRef } from 'react';
import MouthView from './components/MouthView';
import { GameStatus, CavityConfig, Tool, ToolCalibration } from './types';
import { audioService } from './services/audioService';

type CalibrationMode = 'none' | 'cavity' | 'aerator' | 'spatula';

const SCRUB_SENSITIVITY_FILL = 0.65;
const PULP_EXPOSURE_THRESHOLD = 110;
const SUCCESS_THRESHOLD = 100;

// User requested: Final Cavity JSON - DO NOT CHANGE
const INITIAL_CAVITIES: CavityConfig[] = [
  {
    "id": "1",
    "x": 17.09693560769905,
    "y": 38.92863661859202,
    "radius": 5.499999999999999,
    "progress": 0,
    "fillProgress": 0,
    "status": GameStatus.IDLE
  }
];

const DEFAULT_CALIBRATION: ToolCalibration = {
  scale: 1.03,
  rotation: -35.00,
  pivotX: -293.00,
  pivotY: 75.00
};

// User requested: Locked Spatula Alignment - DO NOT CHANGE
const DEFAULT_SPATULA_CALIBRATION: ToolCalibration = {
  scale: 1.03,
  rotation: 141.00,
  pivotX: -589.00,
  pivotY: -78.00
};

export default function App() {
  const [cavities, setCavities] = useState<CavityConfig[]>(INITIAL_CAVITIES);
  const [activeId, setActiveId] = useState<string | null>(null);
  const [currentTool, setCurrentTool] = useState<Tool>(Tool.AERATOR);
  const [calibrationMode, setCalibrationMode] = useState<CalibrationMode>('none');
  const [calibration, setCalibration] = useState<ToolCalibration>(DEFAULT_CALIBRATION);
  const [spatulaCalibration, setSpatulaCalibration] = useState<ToolCalibration>(DEFAULT_SPATULA_CALIBRATION);
  const [resetKey, setResetKey] = useState(0);
  const [showSuccessModal, setShowSuccessModal] = useState(false);

  const activeCavity = cavities.find(c => c.id === activeId) || null;

  // Monitor for game completion
  useEffect(() => {
    const isFinished = cavities.every(c => c.status === GameStatus.SUCCESS);
    if (isFinished && cavities.length > 0 && !showSuccessModal) {
      const timer = setTimeout(() => {
        setShowSuccessModal(true);
        audioService.playSuccessSpeech();
      }, 1200);
      return () => clearTimeout(timer);
    }
  }, [cavities, showSuccessModal]);

  const resetGame = () => {
    setCavities(INITIAL_CAVITIES.map(c => ({ ...c, progress: 0, fillProgress: 0, status: GameStatus.IDLE })));
    setActiveId(null);
    setCurrentTool(Tool.AERATOR);
    setResetKey(prev => prev + 1);
    setShowSuccessModal(false);
    audioService.stopBuzz();
  };

  const handleMouseDown = useCallback((id: string) => {
    if (calibrationMode !== 'none') {
      setActiveId(id);
      return;
    }
    
    const target = cavities.find(c => id === c.id);
    if (!target) return;
    if (target.status === GameStatus.PULP_EXPOSURE || target.status === GameStatus.SUCCESS) return;

    setActiveId(id);

    if (currentTool === Tool.AERATOR) {
        audioService.startBuzz();
    }
  }, [cavities, calibrationMode, currentTool]);

  const handleProgressUpdate = useCallback((id: string, progress: number) => {
    if (calibrationMode !== 'none') return;
    
    setCavities(prev => prev.map(c => {
      if (c.id !== id) return c;
      if (c.status === GameStatus.PULP_EXPOSURE || c.status === GameStatus.SUCCESS) return c;
      if (c.status === GameStatus.PREPPED || c.status === GameStatus.FILLING) return c;

      const isComplete = progress >= SUCCESS_THRESHOLD;
      const nextStatus = isComplete ? GameStatus.PREPPED : GameStatus.DRILLING;
      
      if (isComplete && c.status !== GameStatus.PREPPED) {
        audioService.stopBuzz();
        audioService.playSuccess();
        setCurrentTool(Tool.SPATULA);
      }

      return { ...c, progress, status: nextStatus };
    }));
  }, [calibrationMode]);

  const handleScrub = useCallback((id: string, distance: number) => {
    if (calibrationMode !== 'none') return;
    
    setCavities(prev => prev.map(c => {
      if (c.id !== id) return c;
      if (c.status !== GameStatus.PREPPED && c.status !== GameStatus.FILLING) return c;

      const nextFill = c.fillProgress + (distance * SCRUB_SENSITIVITY_FILL);
      
      if (Math.random() > 0.90) audioService.playSpatula();
      
      if (nextFill >= 100) {
        audioService.playSuccess();
        return { ...c, fillProgress: 100, status: GameStatus.SUCCESS };
      }
      return { ...c, fillProgress: nextFill, status: GameStatus.FILLING };
    }));
  }, [calibrationMode]);

  const handleMouseUp = useCallback(() => {
    if (calibrationMode !== 'none') return;
    if (!activeId) return;

    audioService.stopBuzz();
    setActiveId(null);
  }, [activeId, calibrationMode]);

  useEffect(() => {
    return () => audioService.stopBuzz();
  }, []);

  const updateCavity = (id: string, updates: Partial<CavityConfig>) => {
    setCavities(prev => prev.map(c => c.id === id ? { ...c, ...updates } : c));
  };

  const updateCalibration = (key: keyof ToolCalibration, value: number) => {
    if (calibrationMode === 'aerator') {
      setCalibration(prev => ({ ...prev, [key]: value }));
    } else if (calibrationMode === 'spatula') {
      setSpatulaCalibration(prev => ({ ...prev, [key]: value }));
    }
  };

  const exportCavities = () => {
    const json = JSON.stringify(cavities, null, 2);
    navigator.clipboard.writeText(json);
    alert('Cavity JSON copied to clipboard!');
  };

  return (
    <div className="min-h-screen flex flex-row items-stretch bg-slate-950 overflow-hidden relative font-sans">
      
      <div className="flex flex-col gap-6 p-6 bg-slate-900/80 border-r border-white/5 backdrop-blur-xl z-50">
        <h2 className="text-[10px] font-black text-slate-500 uppercase tracking-[0.3em] mb-4 text-center">Instruments</h2>
        <ToolButton 
          active={currentTool === Tool.AERATOR} 
          onClick={() => setCurrentTool(Tool.AERATOR)}
          label="Bur 330"
          icon="https://res.cloudinary.com/dqwydvc0p/image/upload/v1769516190/IMG-20260127-WA0004_kbmjuz.png"
        />
        <ToolButton 
          active={currentTool === Tool.SPATULA} 
          onClick={() => setCurrentTool(Tool.SPATULA)}
          label="Spatula"
          icon="https://res.cloudinary.com/dqwydvc0p/image/upload/v1769625411/IMG-20260128-WA0072_wvjhhv.png"
        />
        
        <div className="mt-auto flex flex-col gap-2 pt-8 border-t border-white/5">
            <button 
                onClick={() => setCalibrationMode(calibrationMode === 'cavity' ? 'none' : 'cavity')}
                className={`w-full py-4 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all shadow-lg ${calibrationMode === 'cavity' ? 'bg-emerald-600 text-white' : 'bg-slate-800 text-slate-400'}`}
            >
                Cavity Align
            </button>
            <button 
                onClick={() => setCalibrationMode(calibrationMode === 'aerator' ? 'none' : 'aerator')}
                className={`w-full py-4 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all shadow-lg ${calibrationMode === 'aerator' ? 'bg-amber-500 text-white' : 'bg-slate-800 text-slate-400'}`}
            >
                Aerator Align
            </button>
            <button 
                onClick={() => setCalibrationMode(calibrationMode === 'spatula' ? 'none' : 'spatula')}
                className={`w-full py-4 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all shadow-lg ${calibrationMode === 'spatula' ? 'bg-sky-500 text-white' : 'bg-slate-800 text-slate-400'}`}
            >
                Spatula Align
            </button>
            <button onClick={resetGame} className="w-full py-3 rounded-xl bg-red-900/20 text-red-500 text-[10px] font-black uppercase tracking-widest hover:bg-red-900/40 transition-colors mt-4">
                Reset
            </button>
        </div>
      </div>

      <div className="flex-1 flex flex-col items-center justify-center p-8 gap-8">
        <div className="w-full max-w-3xl bg-slate-900/90 p-8 rounded-[2.5rem] border border-white/10 shadow-[0_25px_50px_rgba(0,0,0,0.5)] flex justify-between items-center">
            <div className="flex flex-col gap-1">
                <div className="flex items-center gap-2">
                    <div className={`w-2 h-2 rounded-full animate-pulse ${activeId ? 'bg-emerald-500' : 'bg-slate-700'}`} />
                    <span className="text-sky-400 text-[11px] font-black uppercase tracking-[0.4em]">
                        {activeCavity?.status === GameStatus.FILLING || activeCavity?.status === GameStatus.PREPPED ? 'Restoration Phase' : 'Cavity Debridement'}
                    </span>
                </div>
                <h1 className="text-white text-2xl font-black tracking-tight">Clinical Unit: Molar #16</h1>
            </div>
            
            <div className="flex flex-col items-end">
                <div className="flex items-baseline gap-2">
                    <span className="text-5xl font-black text-white tabular-nums drop-shadow-md">
                        {activeCavity ? (
                            activeCavity.status === GameStatus.PREPPED || activeCavity.status === GameStatus.FILLING || activeCavity.status === GameStatus.SUCCESS
                            ? Math.floor(activeCavity.fillProgress) 
                            : Math.floor(Math.min(100, activeCavity.progress))
                        ) : 0}
                    </span>
                    <span className="text-sky-500 font-black text-lg">%</span>
                </div>
            </div>
        </div>

        <div className="relative w-full aspect-[4/3] max-w-4xl bg-black rounded-[3rem] overflow-hidden border-[10px] border-slate-900 shadow-[0_0_100px_rgba(0,0,0,0.8)]">
          <MouthView 
            key={resetKey}
            cavities={cavities}
            activeId={activeId}
            onMouseDown={handleMouseDown}
            onMouseUp={handleMouseUp}
            onScrub={handleScrub}
            onProgressUpdate={handleProgressUpdate}
            isDesignerMode={calibrationMode === 'cavity'}
            onUpdateCavity={updateCavity}
            currentTool={currentTool}
            calibration={calibration}
            spatulaCalibration={spatulaCalibration}
          />

          {activeCavity?.status === GameStatus.PULP_EXPOSURE && (
            <div className="absolute inset-0 bg-red-950/95 backdrop-blur-md flex items-center justify-center z-[200]">
              <div className="text-center p-12">
                <div className="text-red-500 font-black text-7xl tracking-tighter animate-bounce mb-2">PULP EXPOSURE</div>
                <button onClick={resetGame} className="mt-10 bg-red-600 text-white px-12 py-5 rounded-2xl font-black uppercase tracking-widest shadow-2xl">Restart Procedure</button>
              </div>
            </div>
          )}
        </div>
      </div>

      {calibrationMode !== 'none' && (
        <div className="w-96 bg-slate-900 border-l border-white/10 p-8 flex flex-col gap-8 overflow-y-auto z-50">
          <div className="flex flex-col gap-2">
            <h3 className={`font-black text-sm uppercase tracking-[0.3em] ${
                calibrationMode === 'cavity' ? 'text-emerald-500' : 
                calibrationMode === 'aerator' ? 'text-amber-500' : 'text-sky-500'
            }`}>
                {calibrationMode === 'cavity' ? 'Cavity Alignment' : 
                 calibrationMode === 'aerator' ? 'Aerator Alignment' : 'Spatula Alignment'}
            </h3>
            <p className="text-slate-500 text-[10px] font-medium leading-relaxed">
              {calibrationMode === 'cavity' 
                ? 'Drag decay site to match molar anatomy. Scroll while hovering to scale.' 
                : 'Adjust sliders until the Tool Tip is locked exactly onto your mouse cursor.'}
            </p>
          </div>
          
          <div className="flex flex-col gap-6">
              {(calibrationMode === 'aerator' || calibrationMode === 'spatula') ? (
                  <>
                    <CalibrationSlider 
                        label="Occlusal Angle" 
                        value={calibrationMode === 'aerator' ? calibration.rotation : spatulaCalibration.rotation} 
                        min={-180} max={180} step={1} 
                        onChange={(v) => updateCalibration('rotation', v)} 
                        color={calibrationMode === 'aerator' ? 'amber' : 'sky'}
                    />
                    <div className="h-px bg-white/5 my-2" />
                    <CalibrationSlider 
                        label="Pivot Alignment X" 
                        value={calibrationMode === 'aerator' ? calibration.pivotX : spatulaCalibration.pivotX} 
                        min={-1000} max={1000} step={1} 
                        onChange={(v) => updateCalibration('pivotX', v)} 
                        color={calibrationMode === 'aerator' ? 'amber' : 'sky'}
                    />
                    <CalibrationSlider 
                        label="Pivot Alignment Y" 
                        value={calibrationMode === 'aerator' ? calibration.pivotY : spatulaCalibration.pivotY} 
                        min={-1000} max={1000} step={1} 
                        onChange={(v) => updateCalibration('pivotY', v)} 
                        color={calibrationMode === 'aerator' ? 'amber' : 'sky'}
                    />
                  </>
              ) : (
                  <div className="flex flex-col gap-4">
                      <div className="p-6 bg-emerald-500/10 rounded-2xl border border-emerald-500/20 text-center">
                          <p className="text-emerald-200 text-xs font-bold mb-4">Click and drag decay icons in the mouth view to reposition.</p>
                          <button 
                            onClick={exportCavities}
                            className="w-full py-4 bg-emerald-600 hover:bg-emerald-500 text-white font-black text-[10px] uppercase tracking-widest rounded-xl shadow-lg transition-all"
                          >
                              Export JSON Configuration
                          </button>
                      </div>
                  </div>
              )}
          </div>

          <div className="mt-auto pt-6 border-t border-white/5">
            <button 
                onClick={() => setCalibrationMode('none')}
                className="w-full py-4 bg-slate-800 text-white font-black text-[10px] uppercase tracking-widest rounded-xl"
            >
                Close Console
            </button>
          </div>
        </div>
      )}

      {/* Success Modal */}
      {showSuccessModal && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-md z-[1000] flex items-center justify-center p-4">
          <div className="bg-white rounded-[3rem] p-10 max-w-md w-full text-center shadow-[0_30px_100px_rgba(0,0,0,0.5)] transform animate-scale-bounce border-8 border-sky-100 relative overflow-hidden">
            <div className="absolute top-0 left-0 w-full h-2 bg-sky-400" />
            <div className="absolute top-4 left-4 text-4xl animate-pulse">✨</div>
            <div className="absolute top-4 right-4 text-4xl animate-pulse delay-100">⭐</div>
            <div className="absolute bottom-4 left-10 text-3xl animate-bounce">💎</div>
            <div className="absolute bottom-10 right-6 text-4xl animate-pulse delay-300">✨</div>

            <div className="mb-6 relative inline-block">
               <div className="absolute inset-0 bg-sky-200 blur-2xl rounded-full opacity-50 animate-pulse" />
               <img 
                 src="https://res.cloudinary.com/dqwydvc0p/image/upload/v1769510429/Gemini_Generated_Image_4dj7lo4dj7lo4dj7_aqgrn2.png" 
                 className="w-32 h-32 object-cover rounded-full border-4 border-sky-400 relative z-10"
                 alt="Healthy Tooth"
               />
            </div>

            <h2 className="text-3xl font-black text-slate-900 mb-4 tracking-tight">Treatment Complete!</h2>
            <p className="text-slate-600 font-medium text-lg leading-relaxed mb-10">
              You've done a wonderful job. I think you will be a great dentist!
            </p>

            <button 
              onClick={resetGame}
              className="w-full py-5 bg-sky-500 hover:bg-sky-400 text-white rounded-2xl font-black text-xl shadow-[0_10px_20px_rgba(14,165,233,0.3)] transition-all active:scale-95 group overflow-hidden relative"
            >
              <span className="relative z-10">New Patient</span>
              <div className="absolute inset-0 bg-white/20 translate-y-full group-hover:translate-y-0 transition-transform duration-300" />
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

function ToolButton({ active, onClick, label, icon }: { active: boolean, onClick: () => void, label: string, icon: string }) {
    return (
        <button 
            onClick={onClick}
            className={`w-24 h-28 flex flex-col items-center justify-center rounded-3xl transition-all border-2 group relative overflow-hidden ${
                active ? 'bg-sky-600 border-white shadow-[0_15px_30px_rgba(14,165,233,0.4)] scale-105' : 'bg-slate-800/40 border-slate-700 text-slate-500 hover:bg-slate-800'
            }`}
        >
            <div className={`absolute inset-0 bg-white/10 opacity-0 transition-opacity ${active ? 'opacity-100' : ''}`} />
            <img src={icon} alt={label} className={`w-12 h-12 mb-2 object-contain relative z-10 transition-all ${active ? 'brightness-110 drop-shadow-md' : 'opacity-20 grayscale group-hover:opacity-60'}`} />
            <span className={`text-[9px] font-black uppercase tracking-tighter relative z-10 ${active ? 'text-white' : 'text-slate-600'}`}>{label}</span>
        </button>
    );
}

function CalibrationSlider({ label, value, min, max, step, onChange, color = 'amber' }: { label: string, value: number, min: number, max: number, step: number, onChange: (v: number) => void, color?: string }) {
    const accentClass = color === 'sky' ? 'accent-sky-500' : 'accent-amber-500';
    const textClass = color === 'sky' ? 'text-sky-500' : 'text-amber-500';
    
    return (
        <div className="flex flex-col gap-3">
            <div className="flex justify-between items-center">
                <label className="text-white font-black text-[10px] uppercase tracking-[0.1em]">{label}</label>
                <span className={`${textClass} font-mono text-xs bg-black/40 px-2 py-0.5 rounded border border-white/5`}>{value.toFixed(2)}</span>
            </div>
            <input 
                type="range" 
                min={min} max={max} step={step} 
                value={value} 
                onChange={(e) => onChange(parseFloat(e.target.value))}
                className={`w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer ${accentClass}`}
            />
        </div>
    );
}
