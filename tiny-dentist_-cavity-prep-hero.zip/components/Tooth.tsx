
import React, { useRef } from 'react';
import { GameStatus, CavityConfig } from '../types';

interface ToothProps {
  status: GameStatus;
  progress: number;
  onMouseDown: () => void;
  onMouseUp: () => void;
  isDesignerMode: boolean;
  cavityConfig: CavityConfig;
  setCavityConfig: (config: CavityConfig) => void;
}

const Tooth: React.FC<ToothProps> = ({ 
  status, 
  progress, 
  onMouseDown, 
  onMouseUp, 
  isDesignerMode, 
  cavityConfig, 
  setCavityConfig 
}) => {
  // Fix: Changed GameStatus.TOO_DEEP to GameStatus.PULP_EXPOSURE as it is the correct status defined in types.ts
  const isTooDeep = status === GameStatus.PULP_EXPOSURE;
  const isSuccess = status === GameStatus.SUCCESS;
  const containerRef = useRef<HTMLDivElement>(null);
  const dragRef = useRef<{ isDragging: boolean } | null>(null);

  const cavityStyle = {
    opacity: isSuccess ? 0 : Math.max(0, 1 - progress / 100),
    transform: `scale(${Math.max(0.1, 1 - progress / 120)})`,
    transition: isDesignerMode ? 'none' : 'opacity 0.2s ease-out, transform 0.2s ease-out',
    cursor: isDesignerMode ? 'move' : 'crosshair',
  };

  const handleDesignerMouseDown = (e: React.MouseEvent) => {
    if (!isDesignerMode) {
      onMouseDown();
      return;
    }
    dragRef.current = { isDragging: true };
  };

  const handleDesignerMouseMove = (e: React.MouseEvent) => {
    if (!isDesignerMode || !dragRef.current?.isDragging || !containerRef.current) return;

    const rect = containerRef.current.getBoundingClientRect();
    const x = ((e.clientX - rect.left) / rect.width) * 100;
    const y = ((e.clientY - rect.top) / rect.height) * 100;

    setCavityConfig({
      ...cavityConfig,
      x: Math.max(0, Math.min(100, x)),
      y: Math.max(0, Math.min(100, y))
    });
  };

  const handleDesignerMouseUp = () => {
    if (dragRef.current) dragRef.current.isDragging = false;
    onMouseUp();
  };

  const handleWheel = (e: React.WheelEvent) => {
    if (!isDesignerMode) return;
    const delta = e.deltaY > 0 ? -1 : 1;
    setCavityConfig({
      ...cavityConfig,
      radius: Math.max(2, Math.min(40, cavityConfig.radius + delta))
    });
  };

  return (
    <div 
      ref={containerRef}
      className="relative w-full h-full overflow-hidden select-none"
      onMouseDown={handleDesignerMouseDown}
      onMouseMove={handleDesignerMouseMove}
      onMouseUp={handleDesignerMouseUp}
      onMouseLeave={handleDesignerMouseUp}
      onWheel={handleWheel}
    >
      {/* Base Tooth Photo - Now fills the whole parent card */}
      <img 
        src="https://res.cloudinary.com/dqwydvc0p/image/upload/v1769510429/Gemini_Generated_Image_4dj7lo4dj7lo4dj7_aqgrn2.png" 
        alt="Tooth Base"
        className={`w-full h-full object-cover transition-all duration-500 ${isTooDeep ? 'brightness-75 sepia-[0.3] hue-rotate-[340deg]' : ''}`}
        draggable={false}
      />

      {/* Overlay SVG for Cavity and Effects */}
      <svg 
        viewBox="0 0 100 100" 
        className="absolute inset-0 w-full h-full pointer-events-none"
      >
        {!isSuccess && (
          <g 
            style={cavityStyle} 
            className="origin-center pointer-events-auto"
          >
            <circle
              cx={cavityConfig.x}
              cy={cavityConfig.y}
              r={cavityConfig.radius}
              fill="url(#cavityGradient)"
              className="opacity-95 drop-shadow-2xl"
              stroke={isDesignerMode ? "white" : "transparent"}
              strokeWidth="0.5"
              strokeDasharray={isDesignerMode ? "1,1" : "0"}
            />
            <defs>
              <radialGradient id="cavityGradient">
                <stop offset="0%" stopColor="#3b1701" />
                <stop offset="60%" stopColor="#5d2a0a" />
                <stop offset="100%" stopColor="#78350f" />
              </radialGradient>
            </defs>
          </g>
        )}

        {isTooDeep && (
           <circle
             cx={cavityConfig.x}
             cy={cavityConfig.y}
             r={cavityConfig.radius * 2}
             fill="none"
             stroke="#ff0000"
             strokeWidth="1.5"
             strokeDasharray="2 2"
             className="animate-[ping_1.5s_infinite]"
           />
        )}
      </svg>

      {isDesignerMode && (
        <div className="absolute top-4 left-4 bg-amber-500/90 text-white text-[10px] px-3 py-1 rounded-full shadow-lg font-black tracking-widest backdrop-blur-sm pointer-events-none">
          DESIGNER MODE
        </div>
      )}

      {isSuccess && <Sparkles centerX={cavityConfig.x} centerY={cavityConfig.y} />}
    </div>
  );
};

const Sparkles: React.FC<{ centerX: number; centerY: number }> = ({ centerX, centerY }) => {
  return (
    <div className="absolute inset-0 pointer-events-none">
      {[...Array(20)].map((_, i) => (
        <div
          key={i}
          className="sparkle absolute text-yellow-300 text-3xl"
          style={{
            top: `${centerY - 15 + Math.random() * 30}%`,
            left: `${centerX - 15 + Math.random() * 30}%`,
            animationDelay: `${Math.random() * 0.4}s`,
          }}
        >
          ✨
        </div>
      ))}
    </div>
  );
};

export default Tooth;
